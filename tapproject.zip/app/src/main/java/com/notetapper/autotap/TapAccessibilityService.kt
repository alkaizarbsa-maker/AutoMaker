package com.notetapper.autotap

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.graphics.Path
import android.graphics.PixelFormat
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.util.DisplayMetrics
import android.view.Gravity
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.widget.Button
import android.widget.LinearLayout
import android.widget.Toast
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import org.json.JSONObject
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit

class TapAccessibilityService : AccessibilityService() {

    companion object {
        var configJson: String? = null
        var running = false
        var instance: TapAccessibilityService? = null
    }

    private val scope = CoroutineScope(Dispatchers.Default)
    private var job: Job? = null
    private var bubble: LinearLayout? = null
    private var toggleBtn: Button? = null
    private val mainHandler = Handler(Looper.getMainLooper())

    override fun onServiceConnected() {
        instance = this
        showBubble()
    }

    override fun onUnbind(intent: Intent?): Boolean {
        hideBubble()
        instance = null
        return super.onUnbind(intent)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    fun startAutomation(json: String) {
        if (running) return
        configJson = json
        running = true
        updateBubble()
        job?.cancel()
        job = scope.launch { runLoop(json) }
    }

    fun stopAutomation() {
        running = false
        job?.cancel()
        updateBubble()
    }

    private suspend fun runLoop(json: String) {
        try {
            val root = JSONObject(json)
            val loopCount = root.optInt("loopCount", 1)
            val loopDelay = root.optInt("loopDelayMs", 800)
            val arr = root.optJSONArray("actions")
            if (arr == null || arr.length() == 0) {
                toast("No taps in config")
                running = false
                updateBubble()
                return
            }
            val size = screenSize()
            val w = size[0]
            val h = size[1]
            var iter = 0
            val maxIter = if (loopCount <= 0) 100000 else loopCount
            while (running && iter < maxIter) {
                for (i in 0 until arr.length()) {
                    if (!running) break
                    val o = arr.getJSONObject(i)
                    doGestureSync(o, w, h)
                    if (!running) break
                    val wait = o.optInt("waitAfterMs", 600)
                    delay(wait.toLong().coerceAtLeast(50))
                }
                iter += 1
                if (!running) break
                if (iter < maxIter) delay(loopDelay.toLong().coerceAtLeast(0))
            }
        } catch (e: Exception) {
            toast("Automation error: " + e.message)
        }
        running = false
        updateBubble()
    }

    private suspend fun doGestureSync(o: JSONObject, w: Int, h: Int) {
        try {
            val x = o.optInt("x", 500).coerceIn(0, 1000)
            val y = o.optInt("y", 500).coerceIn(0, 1000)
            val type = o.optString("type", "tap")
            var hold = o.optInt("holdMs", 120)
            val dx = o.optInt("dx", 0)
            val dy = o.optInt("dy", 0)
            val px = x / 1000f * w
            val py = y / 1000f * h
            val builder = GestureDescription.Builder()
            if (type == "swipe") {
                if (hold < 200) hold = 350
                val p = Path()
                p.moveTo(px, py)
                val dxPx = dx / 1000f * w
                val dyPx = dy / 1000f * h
                p.lineTo(px + dxPx, py + dyPx)
                builder.addStroke(GestureDescription.StrokeDescription(p, 0, hold.toLong().coerceIn(50, 5000)))
            } else if (type == "long") {
                if (hold < 400) hold = 800
                val p = Path()
                p.moveTo(px, py)
                builder.addStroke(GestureDescription.StrokeDescription(p, 0, hold.toLong().coerceIn(100, 5000)))
            } else if (type == "double") {
                val p1 = Path()
                p1.moveTo(px, py)
                val p2 = Path()
                p2.moveTo(px, py)
                builder.addStroke(GestureDescription.StrokeDescription(p1, 0, 80))
                builder.addStroke(GestureDescription.StrokeDescription(p2, 200, 80))
            } else {
                val p = Path()
                p.moveTo(px, py)
                val d = hold.toLong().coerceIn(1, 5000)
                val dur = if (d < 80) 80 else d
                builder.addStroke(GestureDescription.StrokeDescription(p, 0, dur))
            }
            val gesture = builder.build()
            val latch = CountDownLatch(1)
            dispatchGesture(gesture, object : GestureDescription.GestureResultCallback() {
                override fun onCompleted(gestureDescription: GestureDescription?) { latch.countDown() }
                override fun onCancelled(gestureDescription: GestureDescription?) { latch.countDown() }
            }, null)
            try { latch.await(6, TimeUnit.SECONDS) } catch (e: Exception) {}
            delay(120)
        } catch (e: Exception) {}
    }

    private fun screenSize(): IntArray {
        val wm = getSystemService(WINDOW_SERVICE) as WindowManager
        if (Build.VERSION.SDK_INT >= 30) {
            val b = wm.currentWindowMetrics.bounds
            return intArrayOf(b.width(), b.height())
        }
        val dm = DisplayMetrics()
        @Suppress("DEPRECATION")
        wm.defaultDisplay.getMetrics(dm)
        return intArrayOf(dm.widthPixels, dm.heightPixels)
    }

    private fun showBubble() {
        if (bubble != null) return
        try {
            val wm = getSystemService(WINDOW_SERVICE) as WindowManager
            val layout = LinearLayout(this)
            layout.orientation = LinearLayout.HORIZONTAL
            val btn = Button(this)
            btn.text = if (running) "Stop" else "Tap:Start"
            btn.setOnClickListener {
                if (running) { stopAutomation() } else {
                    val json = configJson ?: readSavedJson()
                    if (json == null) {
                        Toast.makeText(this, "No tap config. Open the app and press Start once.", Toast.LENGTH_LONG).show()
                    } else {
                        startAutomation(json)
                    }
                }
            }
            layout.addView(btn)
            val params = WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
                PixelFormat.TRANSLUCENT
            )
            params.gravity = Gravity.TOP or Gravity.START
            params.x = 20
            params.y = 200
            wm.addView(layout, params)
            bubble = layout
            toggleBtn = btn
        } catch (e: Exception) {}
    }

    private fun hideBubble() {
        try {
            val wm = getSystemService(WINDOW_SERVICE) as WindowManager
            if (bubble != null) wm.removeView(bubble)
        } catch (e: Exception) {}
        bubble = null
        toggleBtn = null
    }

    private fun updateBubble() {
        mainHandler.post {
            try { toggleBtn?.text = if (running) "Stop" else "Tap:Start" } catch (e: Exception) {}
        }
    }

    private fun toast(msg: String) {
        mainHandler.post {
            try { Toast.makeText(this, msg, Toast.LENGTH_SHORT).show() } catch (e: Exception) {}
        }
    }

    private fun readSavedJson(): String? {
        return try {
            openFileInput("taps.json").bufferedReader().use { it.readText() }
        } catch (e: Exception) { null }
    }
}
