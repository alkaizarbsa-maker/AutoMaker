package com.notetapper.autotap

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.text.Editable
import android.text.TextUtils
import android.text.TextWatcher
import android.view.Gravity
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import org.json.JSONObject

class MainActivity : AppCompatActivity() {

    data class Row(var x: Int, var y: Int, var type: String, var holdMs: Int, var waitAfterMs: Int, var dx: Int, var dy: Int)

    private val rows = ArrayList<Row>()
    private lateinit var tapContainer: LinearLayout
    private lateinit var nameInput: EditText
    private lateinit var pkgInput: EditText
    private lateinit var loopCountInput: EditText
    private lateinit var loopDelayInput: EditText
    private lateinit var statusText: TextView
    private lateinit var jsonEdit: EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        tapContainer = findViewById(R.id.tapContainer)
        nameInput = findViewById(R.id.nameInput)
        pkgInput = findViewById(R.id.pkgInput)
        loopCountInput = findViewById(R.id.loopCountInput)
        loopDelayInput = findViewById(R.id.loopDelayInput)
        statusText = findViewById(R.id.statusText)
        jsonEdit = findViewById(R.id.jsonEdit)
        findViewById<Button>(R.id.addTapBtn).setOnClickListener {
            rows.add(Row(500, 500, "tap", 120, 600, 0, 0))
            renderRows()
            refreshJson()
        }
        findViewById<Button>(R.id.clearBtn).setOnClickListener { rows.clear(); renderRows(); refreshJson() }
        findViewById<Button>(R.id.saveBtn).setOnClickListener {
            val json = collectJson()
            saveToFile(json)
            TapAccessibilityService.configJson = json
            jsonEdit.setText(json)
            toast("Saved " + rows.size + " taps")
            updateStatus()
        }
        findViewById<Button>(R.id.loadSampleBtn).setOnClickListener { loadSample() }
        findViewById<Button>(R.id.applyJsonBtn).setOnClickListener {
            try {
                loadFromJson(jsonEdit.text.toString())
                toast("JSON applied")
            } catch (e: Exception) { toast("Bad JSON: " + e.message) }
        }
        findViewById<Button>(R.id.accessBtn).setOnClickListener {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }
        findViewById<Button>(R.id.overlayBtn).setOnClickListener {
            if (!Settings.canDrawOverlays(this)) {
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + packageName)))
            } else { toast("Overlay already allowed") }
        }
        findViewById<Button>(R.id.startBtn).setOnClickListener {
            val json = collectJson()
            saveToFile(json)
            TapAccessibilityService.configJson = json
            val svc = TapAccessibilityService.instance
            if (svc != null) { svc.startAutomation(json); toast("Running"); }
            else { toast("Enable accessibility first, then use the floating bubble"); startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
            updateStatus()
        }
        findViewById<Button>(R.id.stopBtn).setOnClickListener {
            TapAccessibilityService.instance?.stopAutomation()
            TapAccessibilityService.running = false
            toast("Stopped")
            updateStatus()
        }
        if (!loadSavedOrSample()) loadSample()
        renderRows()
        refreshJson()
        updateStatus()
    }

    override fun onResume() { super.onResume(); updateStatus() }

    private fun updateStatus() {
        val on = isAccessEnabled()
        val run = TapAccessibilityService.running
        statusText.text = "Taps: " + rows.size + " | Accessibility: " + (if (on) "ON" else "OFF") + " | " + (if (run) "RUNNING" else "idle")
    }

    private fun isAccessEnabled(): Boolean {
        val expected = packageName + "/" + TapAccessibilityService::class.java.name
        val enabled = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: return false
        val splitter = TextUtils.SimpleStringSplitter(':')
        splitter.setString(enabled)
        while (splitter.hasNext()) { if (splitter.next().equals(expected, ignoreCase = true)) return true }
        return false
    }

    private fun collectJson(): String {
        val root = JSONObject()
        root.put("name", nameInput.text.toString())
        root.put("packageName", pkgInput.text.toString())
        root.put("loopCount", loopCountInput.text.toString().toIntOrNull() ?: 1)
        root.put("loopDelayMs", loopDelayInput.text.toString().toIntOrNull() ?: 800)
        val arr = org.json.JSONArray()
        for (r in rows) {
            val o = JSONObject()
            o.put("x", r.x); o.put("y", r.y); o.put("type", r.type)
            o.put("holdMs", r.holdMs); o.put("waitAfterMs", r.waitAfterMs)
            o.put("dx", r.dx); o.put("dy", r.dy)
            arr.put(o)
        }
        root.put("actions", arr)
        return root.toString(2)
    }

    private fun loadFromJson(s: String) {
        val cfg = TapConfig.fromJson(s)
        nameInput.setText(cfg.name)
        pkgInput.setText(cfg.packageName)
        loopCountInput.setText(cfg.loopCount.toString())
        loopDelayInput.setText(cfg.loopDelayMs.toString())
        rows.clear()
        for (a in cfg.actions) rows.add(Row(a.x, a.y, a.type, a.holdMs, a.waitAfterMs, a.dx, a.dy))
        renderRows()
        refreshJson()
        updateStatus()
    }

    private fun loadSample() {
        try {
            val s = assets.open("sample-taps.json").bufferedReader().use { it.readText() }
            loadFromJson(s)
        } catch (e: Exception) {
            rows.clear()
            rows.add(Row(500, 300, "tap", 120, 600, 0, 0))
            loopCountInput.setText("1")
            loopDelayInput.setText("800")
            renderRows()
            refreshJson()
        }
    }

    private fun loadSavedOrSample(): Boolean {
        try {
            val s = openFileInput("taps.json").bufferedReader().use { it.readText() }
            loadFromJson(s)
            return true
        } catch (e: Exception) { return false }
    }

    private fun saveToFile(json: String) {
        try { openFileOutput("taps.json", MODE_PRIVATE).use { it.write(json.toByteArray()) } } catch (e: Exception) {}
    }

    private fun refreshJson() { try { jsonEdit.setText(collectJson()) } catch (e: Exception) {} }
    private fun toast(m: String) { Toast.makeText(this, m, Toast.LENGTH_SHORT).show() }

    private fun renderRows() {
        tapContainer.removeAllViews()
        for (idx in rows.indices) {
            val r = rows[idx]
            val card = LinearLayout(this)
            card.orientation = LinearLayout.VERTICAL
            card.setPadding(8, 8, 8, 8)
            val l1 = LinearLayout(this)
            l1.orientation = LinearLayout.HORIZONTAL
            val num = TextView(this)
            num.text = "#" + (idx + 1)
            num.setPadding(4, 20, 4, 4)
            l1.addView(num)
            val sp = Spinner(this)
            val types = arrayOf("tap", "double", "long", "swipe")
            val ad = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, types)
            sp.adapter = ad
            sp.setSelection(Math.max(0, types.indexOf(r.type)))
            sp.layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1.2f)
            val pos = idx
            sp.setOnItemSelectedListener(object : android.widget.AdapterView.OnItemSelectedListener {
                override fun onItemSelected(p: android.widget.AdapterView<*>?, v: android.view.View?, p2: Int, p3: Long) {
                    rows[pos].type = types[p2]
                    refreshJson()
                }
                override fun onNothingSelected(p: android.widget.AdapterView<*>?) {}
            })
            l1.addView(sp)
            l1.addView(numEdit(r.x, 0, 1000) { rows[pos].x = it; refreshJson() })
            l1.addView(numEdit(r.y, 0, 1000) { rows[pos].y = it; refreshJson() })
            val del = Button(this)
            del.text = "X"
            del.setOnClickListener { rows.removeAt(pos); renderRows(); refreshJson() }
            l1.addView(del)
            card.addView(l1)
            val l2 = LinearLayout(this)
            l2.orientation = LinearLayout.HORIZONTAL
            l2.addView(smallNumEdit(r.holdMs, "hold") { rows[pos].holdMs = it; refreshJson() })
            l2.addView(smallNumEdit(r.waitAfterMs, "wait") { rows[pos].waitAfterMs = it; refreshJson() })
            l2.addView(smallNumEdit(r.dx, "dx") { rows[pos].dx = it; refreshJson() })
            l2.addView(smallNumEdit(r.dy, "dy") { rows[pos].dy = it; refreshJson() })
            val up = Button(this)
            up.text = "^"
            up.isEnabled = idx > 0
            up.setOnClickListener { if (pos > 0) { val t = rows[pos - 1]; rows[pos - 1] = rows[pos]; rows[pos] = t; renderRows(); refreshJson() } }
            l2.addView(up)
            val dn = Button(this)
            dn.text = "v"
            dn.isEnabled = idx < rows.size - 1
            dn.setOnClickListener { if (pos < rows.size - 1) { val t = rows[pos + 1]; rows[pos + 1] = rows[pos]; rows[pos] = t; renderRows(); refreshJson() } }
            l2.addView(dn)
            card.addView(l2)
            val hint = TextView(this)
            hint.text = "x y | hold wait dx dy"
            hint.textSize = 10f
            hint.gravity = Gravity.CENTER
            card.addView(hint)
            tapContainer.addView(card)
        }
        updateStatus()
    }

    private fun numEdit(v: Int, min: Int, max: Int, on: (Int) -> Unit): EditText {
        val e = EditText(this)
        e.setText(v.toString())
        e.inputType = android.text.InputType.TYPE_CLASS_NUMBER or android.text.InputType.TYPE_NUMBER_FLAG_SIGNED
        e.layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        e.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) {
                val n = s.toString().toIntOrNull() ?: return
                on(n.coerceIn(min, max))
            }
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
        })
        return e
    }

    private fun smallNumEdit(v: Int, hint: String, on: (Int) -> Unit): EditText {
        val e = EditText(this)
        e.setText(v.toString())
        e.hint = hint
        e.textSize = 12f
        e.inputType = android.text.InputType.TYPE_CLASS_NUMBER or android.text.InputType.TYPE_NUMBER_FLAG_SIGNED
        e.layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        e.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) {
                val n = s.toString().toIntOrNull() ?: return
                on(n)
            }
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
        })
        return e
    }
}
