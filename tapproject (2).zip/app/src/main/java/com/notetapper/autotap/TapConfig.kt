package com.notetapper.autotap

import org.json.JSONArray
import org.json.JSONObject

data class TapAction(
    val x: Int,
    val y: Int,
    val type: String,
    val holdMs: Int,
    val waitAfterMs: Int,
    val dx: Int,
    val dy: Int
)

data class AutomationConfig(
    val name: String,
    val packageName: String,
    val loopCount: Int,
    val loopDelayMs: Int,
    val actions: List<TapAction>
)

object TapConfig {
    fun toJson(c: AutomationConfig): String {
        val root = JSONObject()
        root.put("name", c.name)
        root.put("packageName", c.packageName)
        root.put("loopCount", c.loopCount)
        root.put("loopDelayMs", c.loopDelayMs)
        val arr = JSONArray()
        for (a in c.actions) {
            val o = JSONObject()
            o.put("x", a.x)
            o.put("y", a.y)
            o.put("type", a.type)
            o.put("holdMs", a.holdMs)
            o.put("waitAfterMs", a.waitAfterMs)
            o.put("dx", a.dx)
            o.put("dy", a.dy)
            arr.put(o)
        }
        root.put("actions", arr)
        return root.toString(2)
    }

    fun fromJson(s: String): AutomationConfig {
        val root = JSONObject(s)
        val arr = root.optJSONArray("actions")
        val list = ArrayList<TapAction>()
        if (arr != null) {
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                list.add(
                    TapAction(
                        x = o.optInt("x", 500),
                        y = o.optInt("y", 500),
                        type = o.optString("type", "tap"),
                        holdMs = o.optInt("holdMs", 120),
                        waitAfterMs = o.optInt("waitAfterMs", 600),
                        dx = o.optInt("dx", 0),
                        dy = o.optInt("dy", 0)
                    )
                )
            }
        }
        return AutomationConfig(
            name = root.optString("name", "My taps"),
            packageName = root.optString("packageName", ""),
            loopCount = root.optInt("loopCount", 1),
            loopDelayMs = root.optInt("loopDelayMs", 800),
            actions = list
        )
    }

    fun sample(): AutomationConfig {
        val list = ArrayList<TapAction>()
        list.add(TapAction(500, 300, "tap", 120, 600, 0, 0))
        list.add(TapAction(850, 850, "tap", 120, 600, 0, 0))
        return AutomationConfig("Sample notes flow", "", 1, 800, list)
    }
}
