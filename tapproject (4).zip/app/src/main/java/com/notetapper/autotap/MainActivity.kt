package com.notetapper.autotap

import android.content.Context
import android.content.Intent
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.text.Editable
import android.text.TextUtils
import android.text.TextWatcher
import android.view.Gravity
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.card.MaterialCardView
import com.google.android.material.switchmaterial.SwitchMaterial
import org.json.JSONObject

class MainActivity : AppCompatActivity() {

    data class Row(var x: Int, var y: Int, var type: String, var holdMs: Int, var waitAfterMs: Int, var dx: Int, var dy: Int)

    private val rows = ArrayList<Row>()
    private lateinit var tapContainer: LinearLayout
    private lateinit var nameInput: EditText
    private lateinit var pkgInput: EditText
    private lateinit var loopCountInput: EditText
    private lateinit var loopDelayInput: EditText
    private lateinit var statusText: TextView
    private lateinit var fixDpWidthInput: EditText
    private lateinit var jsonEdit: EditText

    override fun attachBaseContext(newBase: Context) {
        super.attachBaseContext(applyFixDp(newBase))
    }

    private fun applyFixDp(base: Context): Context {
        try {
            val p = base.getSharedPreferences("display", Context.MODE_PRIVATE)
            if (!p.getBoolean("fixdp_on", true)) return base
            val w = p.getInt("fixdp_width", 520).coerceIn(320, 800)
            val dm = base.resources.displayMetrics
            if (dm.widthPixels <= 0) return base
            val conf = android.content.res.Configuration(base.resources.configuration)
            conf.densityDpi = (dm.widthPixels / w.toFloat() * 160).toInt().coerceIn(120, 640)
            return base.createConfigurationContext(conf)
        } catch (e: Exception) { return base }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        enableImmersive()
        tapContainer = findViewById(R.id.tapContainer)
        nameInput = findViewById(R.id.nameInput)
        pkgInput = findViewById(R.id.pkgInput)
        loopCountInput = findViewById(R.id.loopCountInput)
        loopDelayInput = findViewById(R.id.loopDelayInput)
        statusText = findViewById(R.id.statusText)
        jsonEdit = findViewById(R.id.jsonEdit)
        findViewById<Button>(R.id.addTapBtn).setOnClickListener {
            rows.add(Row(500, 500, "tap", 120, 600, 0, 0))
            renderRows()
            refreshJson()
        }
        findViewById<Button>(R.id.clearBtn).setOnClickListener { rows.clear(); renderRows(); refreshJson() }
        findViewById<Button>(R.id.saveBtn).setOnClickListener {
            val json = collectJson()
            saveToFile(json)
            TapAccessibilityService.configJson = json
            TapAccessibilityService.instance?.refreshMarkers()
            jsonEdit.setText(json)
            toast("Saved " + rows.size + " taps")
            updateStatus()
        }
        findViewById<Button>(R.id.loadSampleBtn).setOnClickListener { loadSample() }
        findViewById<Button>(R.id.applyJsonBtn).setOnClickListener {
            try {
                loadFromJson(jsonEdit.text.toString())
                toast("JSON applied")
            } catch (e: Exception) { toast("Bad JSON: " + e.message) }
        }
        findViewById<Button>(R.id.accessBtn).setOnClickListener {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }
        findViewById<Button>(R.id.overlayBtn).setOnClickListener {
            if (!Settings.canDrawOverlays(this)) {
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + packageName)))
            } else { toast("Overlay already allowed") }
        }
        findViewById<Button>(R.id.bubbleBtn).setOnClickListener {
            val svc = TapAccessibilityService.instance
            if (svc != null) {
                svc.toggleBubble()
                toast(if (svc.isBubbleShown()) "Floating button shown" else "Floating button hidden")
            } else { toast("Enable accessibility first, then use this") }
        }
        findViewById<Button>(R.id.previewBtn).setOnClickListener { showPreview() }
        fixDpWidthInput = findViewById(R.id.fixDpWidthInput)
        val prefs = getSharedPreferences("display", MODE_PRIVATE)
        val fixSw = findViewById<SwitchMaterial>(R.id.fixDpSwitch)
        fixSw.isChecked = prefs.getBoolean("fixdp_on", true)
        fixDpWidthInput.setText(prefs.getInt("fixdp_width", 520).toString())
        findViewById<Button>(R.id.applyDisplayBtn).setOnClickListener {
            val w = fixDpWidthInput.text.toString().toIntOrNull()?.coerceIn(320, 800) ?: 520
            fixDpWidthInput.setText(w.toString())
            prefs.edit().putBoolean("fixdp_on", fixSw.isChecked).putInt("fixdp_width", w).apply()
            toast(if (fixSw.isChecked) "Fixed " + w + "dp screen on" else "System screen size on")
            recreate()
        }
        findViewById<Button>(R.id.startBtn).setOnClickListener {
            val json = collectJson()
            saveToFile(json)
            TapAccessibilityService.configJson = json
            val svc = TapAccessibilityService.instance
            if (svc != null) { svc.startAutomation(json); toast("Running"); }
            else { toast("Enable accessibility first, then use the floating bubble"); startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
            updateStatus()
        }
        findViewById<Button>(R.id.stopBtn).setOnClickListener {
            TapAccessibilityService.instance?.stopAutomation()
            TapAccessibilityService.running = false
            toast("Stopped")
            updateStatus()
        }
        if (!loadSavedOrSample()) loadSample()
        renderRows()
        refreshJson()
        updateStatus()
    }

    override fun onResume() { super.onResume(); updateStatus() }

    private fun updateStatus() {
        val on = isAccessEnabled()
        val run = TapAccessibilityService.running
        statusText.text = "Taps: " + rows.size + " | Accessibility: " + (if (on) "ON" else "OFF") + " | " + (if (run) "RUNNING" else "idle") + " | " + screenDp() + "dp"
    }

    private fun isAccessEnabled(): Boolean {
        val expected = packageName + "/" + TapAccessibilityService::class.java.name
        val enabled = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: return false
        val splitter = TextUtils.SimpleStringSplitter(':')
        splitter.setString(enabled)
        while (splitter.hasNext()) { if (splitter.next().equals(expected, ignoreCase = true)) return true }
        return false
    }

    private fun collectJson(): String {
        val root = JSONObject()
        root.put("name", nameInput.text.toString())
        root.put("packageName", pkgInput.text.toString())
        root.put("loopCount", loopCountInput.text.toString().toIntOrNull() ?: 1)
        root.put("loopDelayMs", loopDelayInput.text.toString().toIntOrNull() ?: 800)
        val arr = org.json.JSONArray()
        for (r in rows) {
            val o = JSONObject()
            o.put("x", r.x); o.put("y", r.y); o.put("type", r.type)
            o.put("holdMs", r.holdMs); o.put("waitAfterMs", r.waitAfterMs)
            o.put("dx", r.dx); o.put("dy", r.dy)
            arr.put(o)
        }
        root.put("actions", arr)
        return root.toString(2)
    }

    private fun loadFromJson(s: String) {
        val cfg = TapConfig.fromJson(s)
        nameInput.setText(cfg.name)
        pkgInput.setText(cfg.packageName)
        loopCountInput.setText(cfg.loopCount.toString())
        loopDelayInput.setText(cfg.loopDelayMs.toString())
        rows.clear()
        for (a in cfg.actions) rows.add(Row(a.x, a.y, a.type, a.holdMs, a.waitAfterMs, a.dx, a.dy))
        renderRows()
        refreshJson()
        updateStatus()
    }

    private fun loadSample() {
        try {
            val s = assets.open("sample-taps.json").bufferedReader().use { it.readText() }
            loadFromJson(s)
        } catch (e: Exception) {
            rows.clear()
            rows.add(Row(500, 300, "tap", 120, 600, 0, 0))
            loopCountInput.setText("1")
            loopDelayInput.setText("800")
            renderRows()
            refreshJson()
        }
    }

    private fun loadSavedOrSample(): Boolean {
        try {
            val s = openFileInput("taps.json").bufferedReader().use { it.readText() }
            loadFromJson(s)
            return true
        } catch (e: Exception) { return false }
    }

    private fun saveToFile(json: String) {
        try { openFileOutput("taps.json", MODE_PRIVATE).use { it.write(json.toByteArray()) } } catch (e: Exception) {}
    }

    private fun refreshJson() { try { jsonEdit.setText(collectJson()) } catch (e: Exception) {} }
    private fun toast(m: String) { Toast.makeText(this, m, Toast.LENGTH_SHORT).show() }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) enableImmersive()
    }

    private fun enableImmersive() {
        try {
            window.statusBarColor = android.graphics.Color.TRANSPARENT
            window.navigationBarColor = android.graphics.Color.TRANSPARENT
        } catch (e: Exception) {}
        @Suppress("DEPRECATION")
        window.decorView.systemUiVisibility = (android.view.View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
            or android.view.View.SYSTEM_UI_FLAG_FULLSCREEN
            or android.view.View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
            or android.view.View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
            or android.view.View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
            or android.view.View.SYSTEM_UI_FLAG_LAYOUT_STABLE)
    }

    private fun typeColor(t: String): Int {
        if (t == "double") return 0xFF60A5FA.toInt()
        if (t == "long") return 0xFFFBBF24.toInt()
        if (t == "swipe") return 0xFFF472B6.toInt()
        return 0xFF4ADE80.toInt()
    }

    private fun showPreview() {
        if (rows.isEmpty()) { toast("Add a tap first"); return }
        val outer = LinearLayout(this)
        outer.orientation = LinearLayout.VERTICAL
        outer.gravity = Gravity.CENTER
        outer.setPadding(dp(8), dp(8), dp(8), dp(8))
        val cap = TextView(this)
        cap.text = "Positions are 0-1000 from the top-left, like the designer."
        cap.textSize = 12f
        cap.setTextColor(0xFF9AA3B2.toInt())
        cap.setPadding(0, 0, 0, dp(8))
        outer.addView(cap)
        val w = dp(200)
        val h = (w * 19.5f / 9f).toInt()
        val frame = FrameLayout(this)
        val bg = GradientDrawable()
        bg.setColor(0xFF101828.toInt())
        bg.cornerRadius = dp(20).toFloat()
        bg.setStroke(dp(2), 0xFF33445F.toInt())
        frame.background = bg
        frame.layoutParams = LinearLayout.LayoutParams(w, h)
        for (idx in rows.indices) {
            val r = rows[idx]
            val dot = TextView(this)
            dot.text = (idx + 1).toString()
            dot.gravity = Gravity.CENTER
            dot.textSize = 12f
            dot.setTypeface(dot.typeface, android.graphics.Typeface.BOLD)
            dot.setTextColor(0xFF06121F.toInt())
            val c = GradientDrawable()
            c.shape = GradientDrawable.OVAL
            c.setColor(typeColor(r.type))
            c.setStroke(dp(2), 0xFFFFFFFF.toInt())
            dot.background = c
            val s = dp(30)
            val lp = FrameLayout.LayoutParams(s, s)
            lp.leftMargin = (r.x / 1000f * w - s / 2).toInt().coerceIn(0, w - s)
            lp.topMargin = (r.y / 1000f * h - s / 2).toInt().coerceIn(0, h - s)
            dot.layoutParams = lp
            frame.addView(dot)
        }
        outer.addView(frame)
        androidx.appcompat.app.AlertDialog.Builder(this)
            .setTitle("Tap positions")
            .setView(outer)
            .setPositiveButton("Close", null)
            .show()
    }

    private fun screenDp(): Int {
        val dm = resources.displayMetrics
        if (dm.density <= 0) return 0
        return (dm.widthPixels / dm.density).toInt()
    }

    private fun dp(v: Int): Int { return (v * resources.displayMetrics.density + 0.5f).toInt() }

    private fun renderRows() {
        tapContainer.removeAllViews()
        if (rows.isEmpty()) {
            val t = TextView(this)
            t.text = "No taps yet. Press Add tap, or load the sample."
            t.textSize = 14f
            t.setTextColor(0xFF9AA3B2.toInt())
            t.setPadding(dp(4), dp(10), dp(4), dp(10))
            tapContainer.addView(t)
        }
        for (idx in rows.indices) {
            val r = rows[idx]
            val pos = idx
            val card = MaterialCardView(this)
            card.radius = dp(14).toFloat()
            card.cardElevation = dp(2).toFloat()
            card.setCardBackgroundColor(0xFF1B2436.toInt())
            card.strokeWidth = dp(1)
            card.strokeColor = 0xFF2A3A55.toInt()
            val clp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
            clp.bottomMargin = dp(10)
            card.layoutParams = clp
            card.setContentPadding(dp(12), dp(10), dp(12), dp(10))
            val inner = LinearLayout(this)
            inner.orientation = LinearLayout.VERTICAL
            val h = LinearLayout(this)
            h.orientation = LinearLayout.HORIZONTAL
            h.gravity = Gravity.CENTER_VERTICAL
            val num = TextView(this)
            num.text = "#" + (idx + 1)
            num.textSize = 15f
            num.setTypeface(num.typeface, android.graphics.Typeface.BOLD)
            num.setTextColor(0xFF06121F.toInt())
            val badge = GradientDrawable()
            badge.shape = GradientDrawable.OVAL
            badge.setColor(typeColor(r.type))
            num.background = badge
            num.setPadding(dp(9), dp(5), dp(9), dp(5))
            h.addView(num)
            val sp = Spinner(this)
            val types = arrayOf("tap", "double", "long", "swipe")
            val ad = ArrayAdapter(this, android.R.layout.simple_spinner_item, types)
            ad.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
            sp.adapter = ad
            sp.setSelection(Math.max(0, types.indexOf(r.type)))
            sp.layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            sp.setOnItemSelectedListener(object : android.widget.AdapterView.OnItemSelectedListener {
                override fun onItemSelected(p: android.widget.AdapterView<*>?, v: android.view.View?, p2: Int, p3: Long) {
                    rows[pos].type = types[p2]
                    refreshJson()
                }
                override fun onNothingSelected(p: android.widget.AdapterView<*>?) {}
            })
            h.addView(sp)
            val up = smallBtn("UP") { if (pos > 0) { val t = rows[pos - 1]; rows[pos - 1] = rows[pos]; rows[pos] = t; renderRows(); refreshJson() } }
            up.isEnabled = idx > 0
            h.addView(up)
            val dn = smallBtn("DN") { if (pos < rows.size - 1) { val t = rows[pos + 1]; rows[pos + 1] = rows[pos]; rows[pos] = t; renderRows(); refreshJson() } }
            dn.isEnabled = idx < rows.size - 1
            h.addView(dn)
            val del = smallBtn("X") { rows.removeAt(pos); renderRows(); refreshJson() }
            del.setTextColor(0xFFF87171.toInt())
            h.addView(del)
            inner.addView(h)
            val p1 = LinearLayout(this)
            p1.orientation = LinearLayout.HORIZONTAL
            p1.gravity = Gravity.CENTER_VERTICAL
            p1.addView(lab("X"))
            p1.addView(numEdit(r.x, "0-1000", 0, 1000, 1f) { rows[pos].x = it; refreshJson() })
            p1.addView(lab("Y"))
            p1.addView(numEdit(r.y, "0-1000", 0, 1000, 1f) { rows[pos].y = it; refreshJson() })
            inner.addView(p1)
            val p2 = LinearLayout(this)
            p2.orientation = LinearLayout.HORIZONTAL
            p2.addView(numEdit(r.holdMs, "hold ms", 1, 5000, 1f) { rows[pos].holdMs = it; refreshJson() })
            p2.addView(numEdit(r.waitAfterMs, "wait ms", 0, 60000, 1f) { rows[pos].waitAfterMs = it; refreshJson() })
            p2.addView(numEdit(r.dx, "dx", -1000, 1000, 0.7f) { rows[pos].dx = it; refreshJson() })
            p2.addView(numEdit(r.dy, "dy", -1000, 1000, 0.7f) { rows[pos].dy = it; refreshJson() })
            inner.addView(p2)
            val cap = TextView(this)
            cap.text = describeType(r.type)
            cap.textSize = 11.5f
            cap.setTextColor(0xFF7B8AA3.toInt())
            cap.setPadding(0, dp(4), 0, 0)
            inner.addView(cap)
            card.addView(inner)
            tapContainer.addView(card)
        }
        updateStatus()
    }

    private fun describeType(t: String): String {
        if (t == "swipe") return "Swipe: drags from the point by dx, dy."
        if (t == "long") return "Long press: holds a finger down."
        if (t == "double") return "Double tap: two quick touches."
        return "Tap: one quick touch."
    }

    private fun lab(s: String): TextView {
        val t = TextView(this)
        t.text = s
        t.textSize = 14f
        t.setTextColor(0xFF9AA3B2.toInt())
        t.setTypeface(t.typeface, android.graphics.Typeface.BOLD)
        val p = LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT)
        p.rightMargin = dp(2)
        t.layoutParams = p
        return t
    }

    private fun smallBtn(text: String, on: () -> Unit): Button {
        val b = Button(this, null, com.google.android.material.R.attr.materialButtonOutlinedStyle)
        b.text = text
        b.textSize = 12f
        b.minimumWidth = 0
        b.minWidth = 0
        b.setPadding(dp(10), 0, dp(10), 0)
        val p = LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT)
        p.leftMargin = dp(4)
        b.layoutParams = p
        b.setOnClickListener { on() }
        return b
    }

    private fun numEdit(v: Int, hint: String, min: Int, max: Int, weight: Float, on: (Int) -> Unit): EditText {
        val e = EditText(this)
        e.setText(v.toString())
        e.hint = hint
        e.textSize = 15f
        e.setTextColor(0xFFFFFFFF.toInt())
        e.setHintTextColor(0xFF5B6B84.toInt())
        e.inputType = android.text.InputType.TYPE_CLASS_NUMBER or android.text.InputType.TYPE_NUMBER_FLAG_SIGNED
        e.setSingleLine(true)
        e.setPadding(dp(10), dp(10), dp(10), dp(10))
        val p = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, weight)
        p.leftMargin = dp(2)
        p.rightMargin = dp(2)
        p.topMargin = dp(4)
        e.layoutParams = p
        e.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) {
                val n = s.toString().toIntOrNull() ?: return
                on(n.coerceIn(min, max))
            }
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
        })
        return e
    }
}
