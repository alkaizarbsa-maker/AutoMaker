# Note Tap Automator (Android app)

Auto-tapper for your Notes app. Taps the screen on its own using an accessibility service.

## Build the APK with GitHub (no local setup)

1. Zip this project folder as tapproject.zip (the web designer downloads it ready-made).
2. Upload tapproject.zip to the repo root. No extracting.
3. Add the workflow file .github/workflows/build-apk.yml (copy it from the web designer).
4. Open the repo Actions tab, enable workflows. Each new zip upload rebuilds automatically.
5. Download the **app-release** artifact. That is your installable APK.
   If Android reports a package conflict, uninstall the old copy once, then install fresh.
   After that every update installs cleanly, because all builds share this repo key.

## Use on the phone (Android 8.0 and newer)

1. Install the APK (allow install from this source when asked).
2. Open system Settings, Accessibility, turn on **Note Tap Automator**.
3. Allow **Display over other apps** for it.
4. Open this app, edit taps if needed, press **Start automation**.
5. Switch to your Notes app. Use the floating **Tap:Start / Stop** bubble to run or stop the taps.

The floating bubble has a Dots button: numbered dots appear over your screen, drag them
to move tap positions, they save automatically.
Coordinates are 0-1000 from the top-left, so one config works on any screen size.
Set loop count 0 for infinite. Keep waits above 300ms so app screens can open.

## Files

- `app/src/main/java/com/notetapper/autotap/MainActivity.kt` — tap list editor UI.
- `app/src/main/java/com/notetapper/autotap/TapAccessibilityService.kt` — gesture engine + floating bubble.
- `app/src/main/java/com/notetapper/autotap/TapConfig.kt` — JSON config model.
- `app/src/main/assets/sample-taps.json` — the sequence exported from the web designer.
